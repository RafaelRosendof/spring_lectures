package com.escola.crud;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class CrudEscolaApplicationTests {

	@Test
	void contextLoads() {
	}

}
