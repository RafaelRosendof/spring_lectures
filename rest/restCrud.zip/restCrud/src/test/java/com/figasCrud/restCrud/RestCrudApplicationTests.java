package com.figasCrud.restCrud;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class RestCrudApplicationTests {

	@Test
	void contextLoads() {
	}

}
